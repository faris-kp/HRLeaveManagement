﻿using System;
using System.Collections.Generic;
using System.Text;

namespace HRLeaveManagement.Application.Persistence.Contracts
{
    internal class ILeaveTypeRepostiory
    {
    }
}
