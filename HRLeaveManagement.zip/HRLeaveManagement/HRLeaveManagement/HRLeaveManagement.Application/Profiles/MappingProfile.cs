﻿using System;
using System.Collections.Generic;
using System.Text;

namespace HRLeaveManagement.Application.Profiles
{
    internal class MappingProfiles
    {
    }
}
