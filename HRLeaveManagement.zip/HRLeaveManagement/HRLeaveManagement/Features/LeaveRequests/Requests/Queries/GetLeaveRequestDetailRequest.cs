﻿using System;
using System.Collections.Generic;
using System.Text;

namespace HRLeaveManagement.Application.Features.LeaveRequests.Requests.Queries
{
    internal class GetLeaveRequestDetailRequest
    {
    }
}
