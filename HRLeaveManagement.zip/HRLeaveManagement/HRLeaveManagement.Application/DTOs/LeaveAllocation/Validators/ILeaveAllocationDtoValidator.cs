﻿using FluentValidation;
using HRLeaveManagement.Application.Persistence.Contracts;
using System;
using System.Collections.Generic;
using System.Text;

namespace HRLeaveManagement.Application.DTOs.LeaveAllocation.Validators
{
    public class ILeaveAllocationDtoValidator : AbstractValidator<ILeaveAllocationDto>
    {
        private readonly ILeaveTypeRepostiory _leaveTypeRepostiory;
        public ILeaveAllocationDtoValidator(ILeaveTypeRepostiory leaveTypeRepostiory)
        {
            _leaveTypeRepostiory = leaveTypeRepostiory;
            RuleFor(p => p.NumberOfDays)
                .GreaterThan(0).WithMessage("{PropertyName} Must be bofore {ComparisonValue}");

            RuleFor(p => p.Period)
                .GreaterThanOrEqualTo(DateTime.Now.Year).WithMessage("{PropertyName} Must be after {ComparisonValue}");

            RuleFor(p => p.LeaveTypeId)
                .GreaterThan(0)
                .MustAsync(async (id, token) =>
                {
                    var leaveTypeExists = await _leaveTypeRepostiory.Exists(id);
                    return !leaveTypeExists;
                }).WithMessage("{PropertyName} does not exist");

        }
    }
  
}        