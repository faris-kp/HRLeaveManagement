﻿using FluentValidation;
using HR.LeaveManagement.Domain;
using HRLeaveManagement.Application.Persistence.Contracts;
using System;
using System.Collections.Generic;
using System.Text;

namespace HRLeaveManagement.Application.DTOs.LeaveAllocation.Validators
{
    public class CreateLeaveAllocationDtoValidator:AbstractValidator<CreateLeaveAllocationDto>
    {
        private readonly ILeaveTypeRepostiory _leaveTypeRepostiory;
        public CreateLeaveAllocationDtoValidator(ILeaveTypeRepostiory leaveTypeRepostiory)
        {
            _leaveTypeRepostiory = leaveTypeRepostiory; 
            Include(new ILeaveAllocationDtoValidator(_leaveTypeRepostiory));
        }

    }
}
