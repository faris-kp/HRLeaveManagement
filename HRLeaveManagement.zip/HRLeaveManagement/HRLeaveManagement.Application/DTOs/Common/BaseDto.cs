﻿using System;
using System.Collections.Generic;
using System.Text;

namespace HRLeaveManagement.Application.DTOs.Common
{
    public abstract class BaseDto
    {
        public int Id { get; set; } 
    }
}
