﻿using FluentValidation;
using HRLeaveManagement.Application.Persistence.Contracts;
using System;
using System.Collections.Generic;
using System.Runtime.InteropServices;
using System.Text;

namespace HRLeaveManagement.Application.DTOs.LeaveRequest.Validators
{
    public class CreateLeaveRequestDtoValidator:AbstractValidator<CreateLeaveRequestDto>
    {
        private readonly ILeaveTypeRepostiory _leaveTypeRepostiory;
        public CreateLeaveRequestDtoValidator(ILeaveTypeRepostiory leaveTypeRepostiory)
        {
         _leaveTypeRepostiory = leaveTypeRepostiory;
            Include(new ILeaveRequestDtoValidator(_leaveTypeRepostiory));
        }
          
    }
}
