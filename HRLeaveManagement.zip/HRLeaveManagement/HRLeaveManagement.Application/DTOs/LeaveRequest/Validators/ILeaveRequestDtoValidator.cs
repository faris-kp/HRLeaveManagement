﻿using FluentValidation;
using HRLeaveManagement.Application.Persistence.Contracts;
using System;
using System.Collections.Generic;
using System.Text;

namespace HRLeaveManagement.Application.DTOs.LeaveRequest.Validators
{
    public class ILeaveRequestDtoValidator:AbstractValidator<ILeaveRequestDto>
    {
        private readonly ILeaveTypeRepostiory _leaveTypeRepostiory;

        public ILeaveRequestDtoValidator(ILeaveTypeRepostiory leaveTypeRepostiory)
        {
            _leaveTypeRepostiory = leaveTypeRepostiory;
            RuleFor(p => p.StartDate)
                .LessThan(p => p.EndDate).WithMessage("" +
                "{PropertyName} must  be before {ComarisonValue}");

            RuleFor(p => p.EndDate)
                .GreaterThan(p => p.StartDate).WithMessage("{PropertyName} must  be before {ComarisonValue}");

            RuleFor(p => p.LeaveTypeId)
                .GreaterThan(0)
                .MustAsync(async (id, token) =>
                {
                    var leaveTypeExists = await _leaveTypeRepostiory.Exists(id);
                    return !leaveTypeExists;
                }
                ).WithMessage("{PropertyName} Does not exist");
            
        }
    }
}
