﻿using AutoMapper;
using HRLeaveManagement.Application.Features.LeaveTypes.Requests.Commands;
using HRLeaveManagement.Application.Persistence.Contracts;
using MediatR;
using System;
using System.Collections.Generic;
using System.Text;
using System.Threading;
using System.Threading.Tasks;

namespace HRLeaveManagement.Application.Features.LeaveTypes.Handlers.Commands
{
    public class DeleteLeaveTypeCommandHandler:IRequestHandler<DeleteLeaveTypeCommand>
    {
        private readonly ILeaveTypeRepostiory _leaveTypeRepostiory;
        private readonly IMapper _mapper;
        public DeleteLeaveTypeCommandHandler(ILeaveTypeRepostiory leaveTypeRepostiory, IMapper mapper)
        {
            _leaveTypeRepostiory = leaveTypeRepostiory;
            _mapper = mapper;
        }

        public async Task<Unit> Handle(DeleteLeaveTypeCommand request, CancellationToken cancellationToken)
        {
            var leaveType = await _leaveTypeRepostiory.Get(request.Id);
            await _leaveTypeRepostiory.Delete(leaveType);

            return Unit.Value;
        }
    }
}
